<!DOCTYPE html>
<html lang="ru" class="bg-white">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Для доп функций tailwind -->
  <script src="https://unpkg.com/flowbite@1.4.4/dist/flowbite.js"></script>
  <!-- tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
    <!-- Слайдер + доп библиотека tailwind -->
  <link href="https://cdn.jsdelivr.net/npm/daisyui@2.14.3/dist/full.css" rel="stylesheet" type="text/css" />
  <!-- Чат бот -->
  <link href="chatbot/chatbot.css" rel="stylesheet" type="text/css" />
  <title>TrudInfo</title>
</head>
<body>
  <!-- Шапка -->
  <header class="container mx-auto px-4 bg-gray-200 z-100;" >
    <div class="flex items-center justify-between flex-wrap p-2">
      <!-- Логотип -->
      <a href="index.php" class="flex items-center flex-shrink-0 mr-14 hover:scale-110 transition delay-150 duration-300 ease-in-out" href="">
        <svg width="100" height="100" viewBox="0 0 673 649" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="326.5" cy="324.5" rx="326.5" ry="324.5" fill="#E32828"/>
        <path d="M500 189.413V554.413H177V113.413C194.771 113.413 211.091 113.413 226.5 113.413M500 189.413L422 113.413M500 189.413H422V113.413M422 113.413C344.092 113.413 294.055 113.413 226.5 113.413M226.5 113.413C226.5 49.412 324 56.4131 317 113.414L321 249.413C310 296.913 232.5 299.913 222.5 246.413V161.413C220 129.413 273.5 127.413 274.5 160.413L273.5 228.413" stroke="white" stroke-width="17" stroke-linejoin="round"/>
        <path d="M275.636 359V346.909H347.682V359H318.636V440H304.636V359H275.636ZM374.704 346.909V440H360.658V346.909H374.704Z" fill="white"/>
        <path d="M275.636 359H270.636V364H275.636V359ZM275.636 346.909V341.909H270.636V346.909H275.636ZM347.682 346.909H352.682V341.909H347.682V346.909ZM347.682 359V364H352.682V359H347.682ZM318.636 359V354H313.636V359H318.636ZM318.636 440V445H323.636V440H318.636ZM304.636 440H299.636V445H304.636V440ZM304.636 359H309.636V354H304.636V359ZM280.636 359V346.909H270.636V359H280.636ZM275.636 351.909H347.682V341.909H275.636V351.909ZM342.682 346.909V359H352.682V346.909H342.682ZM347.682 354H318.636V364H347.682V354ZM313.636 359V440H323.636V359H313.636ZM318.636 435H304.636V445H318.636V435ZM309.636 440V359H299.636V440H309.636ZM304.636 354H275.636V364H304.636V354ZM374.704 346.909H379.704V341.909H374.704V346.909ZM374.704 440V445H379.704V440H374.704ZM360.658 440H355.658V445H360.658V440ZM360.658 346.909V341.909H355.658V346.909H360.658ZM369.704 346.909V440H379.704V346.909H369.704ZM374.704 435H360.658V445H374.704V435ZM365.658 440V346.909H355.658V440H365.658ZM360.658 351.909H374.704V341.909H360.658V351.909Z" fill="white"/>
        </svg>
        <span class="text-5xl text-gray-600 font-bold tracking-tight">TrudInfo</span>
      </a>
      <div class="w-full block flex-grow lg:flex lg:items-center lg:w-auto mt-3">
        <div class="text-2xl lg:flex-grow">
          <!-- Навигация 1 -->
          <div class="group inline-block relative mx-4">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-2 px-12 rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out">
                <span class="mr-1">Услуги</span>
                <svg
                  class="fill-current h-4 w-4"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20">
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </button>
              <!-- Выпадающий список 1 -->
              <ul class="absolute hidden text-white pt-1 group-hover:block z-30">
                <li class="">
                  <a
                    class="rounded-t bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Поиск работы
                  </a>
                </li>
                <li class="">
                  <a
                    class="bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Новые вакансии
                  </a>
                </li>
                <li class="">
                  <a
                    class="rounded-b bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">О конкурсах
                  </a>
                </li>
              </ul>
            </div>
            <!-- Навигация 2 -->
             <div class="group inline-block relative mx-2">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-2 px-12 rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out ">
                <span >Конкурсы</span>
              </button>
            </div>
            <!-- Навигация 3 -->
             <div class="group inline-block relative mx-4">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-2 px-12 rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out">
                <span class="mr-1">Документация</span>
                <svg
                  class="fill-current h-4 w-4"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20">
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </button>
              <!-- Выпадающий список 3 -->
              <ul class="absolute hidden text-white pt-1 group-hover:block z-30">
                <li class="">
                  <a
                    class="rounded-t bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Один
                  </a>
                </li>
                <li class="">
                  <a
                    class="bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Два
                  </a>
                </li>
                <li class="">
                  <a
                    class="rounded-b bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Три
                  </a>
                </li>
              </ul>
            </div>
            <!-- Навигация 4 -->
             <div class="group inline-block relative mx-4">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-2 px-12 rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out">
                <span class="mr-1">Акты</span>
                <svg
                  class="fill-current h-4 w-4"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20">
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </button>
              <!-- Выпадающий список 4 -->
              <ul class="absolute hidden text-white pt-1 group-hover:block z-30">
                <li class="">
                  <a
                    class="rounded-t bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Arbitrary values
                  </a>
                </li>
                <li class="">
                  <a
                    class="bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Arbitrary valuesавыаыв
                  </a>
                </li>
                <li class="">
                  <a
                    class="rounded-b bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Arbitrary valuesваааааааааап
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
  </header>
  <!-- Основа -->
  <main>
    <div class="container mx-auto my-10 max-w-6xl">
      <span class="text-center text-5xl text-black">Конкурсы</span>
      <div class="mt-10 relative overflow-x-auto shadow-md sm:rounded-lg">
          <table class="w-full text-2xl text-left text-gray-500 dark:text-gray-400">
              <thead class="text-2xl text-black uppercase bg-gray-50 dark:bg-gray-300 dark:text-black">
                  <tr>
                      <th scope="col" class="px-12 py-10">
                          Дата
                      </th>
                      <th scope="col" class="px-12 py-10">
                          Название конкурса
                      </th>
                      <th scope="col" class="px-12 py-10">
                          Возраст
                      </th>
                  </tr>
              </thead>
              <tbody>
                  <tr class="bg-red-400 border-b text-black">
                      <th scope="row" class="px-12 py-10 font-medium text-gray-700 dark:text-black whitespace-nowrap">
                          04.05.2022
                      </th>
                      <td class="px-12 py-10">
                          Финал mpit среди студентов
                      </td>
                      <td class="px-12 py-10">
                          16-21 лет
                      </td>
                  </tr>
                  <tr class="bg-white border-b dark:text-gray-700 dark:border-gray-700">
                      <th scope="row" class="px-12 py-10 font-medium text-gray-700 dark:text-black whitespace-nowrap">
                          15.11.2022
                      </th>
                      <td class="px-12 py-10">
                          Конкурс пожилых специалистов в сфере
                      </td>
                      <td class="px-12 py-10">
                          40-65 лет
                      </td>
                  </tr>
                  <tr class="bg-white border-b dark:text-gray-700 dark:border-gray-700">
                      <th scope="row" class="px-12 py-10 font-medium text-gray-700 dark:text-black whitespace-nowrap">
                          6.12.2022
                      </th>
                      <td class="px-12 py-10">
                          Конкурс на лучшего менеджера среди компаний
                      </td>
                      <td class="px-12 py-10">
                          18-45 лет
                      </td>
                  </tr>
              </tbody>
          </table>
      </div>
    </div>
  <!-- Подвал -->
  <footer class="p-4 bg-white shadow md:px-6 md:py-8 dark:bg-gray-800">
    <div class="sm:flex sm:items-center sm:justify-between">
        <a class="flex items-center flex-shrink-0 mr-14 hover:scale-110 transition delay-150 duration-300 ease-in-out" href="">
        <svg width="92" height="136" viewBox="0 0 92 136" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M89 35.4492V133H3V15.1373C7.73147 15.1373 12.0769 15.1373 16.1796 15.1373M89 35.4492L68.2322 15.1373M89 35.4492H68.2322V15.1373M68.2322 15.1373C47.4889 15.1373 34.1663 15.1373 16.1796 15.1373M16.1796 15.1373C16.1796 -1.96788 42.1393 -0.0967461 40.2755 15.1375L41.3406 51.4849C38.4118 64.1799 17.7771 64.9816 15.1146 50.6831V27.9658C14.4489 19.4134 28.6935 18.8789 28.9598 27.6985L28.6935 45.8724" stroke="white" stroke-width="5" stroke-linejoin="round"/>
          <path d="M26.7173 83.3203V79.6364H48.6687V83.3203H39.8189V108H35.5533V83.3203H26.7173ZM56.9019 79.6364V108H52.6224V79.6364H56.9019Z" fill="white"/>
          <path d="M26.7173 83.3203H25.7173V84.3203H26.7173V83.3203ZM26.7173 79.6364V78.6364H25.7173V79.6364H26.7173ZM48.6687 79.6364H49.6687V78.6364H48.6687V79.6364ZM48.6687 83.3203V84.3203H49.6687V83.3203H48.6687ZM39.8189 83.3203V82.3203H38.8189V83.3203H39.8189ZM39.8189 108V109H40.8189V108H39.8189ZM35.5533 108H34.5533V109H35.5533V108ZM35.5533 83.3203H36.5533V82.3203H35.5533V83.3203ZM27.7173 83.3203V79.6364H25.7173V83.3203H27.7173ZM26.7173 80.6364H48.6687V78.6364H26.7173V80.6364ZM47.6687 79.6364V83.3203H49.6687V79.6364H47.6687ZM48.6687 82.3203H39.8189V84.3203H48.6687V82.3203ZM38.8189 83.3203V108H40.8189V83.3203H38.8189ZM39.8189 107H35.5533V109H39.8189V107ZM36.5533 108V83.3203H34.5533V108H36.5533ZM35.5533 82.3203H26.7173V84.3203H35.5533V82.3203ZM56.9019 79.6364H57.9019V78.6364H56.9019V79.6364ZM56.9019 108V109H57.9019V108H56.9019ZM52.6224 108H51.6224V109H52.6224V108ZM52.6224 79.6364V78.6364H51.6224V79.6364H52.6224ZM55.9019 79.6364V108H57.9019V79.6364H55.9019ZM56.9019 107H52.6224V109H56.9019V107ZM53.6224 108V79.6364H51.6224V108H53.6224ZM52.6224 80.6364H56.9019V78.6364H52.6224V80.6364Z" fill="white"/>
          </svg>
        <span class="text-5xl text-white font-roboto tracking-tight">TrudInfo</span>
      </a>
      <a class="flex items-center flex-shrink-0 mr-14 hover:scale-110 transition delay-150 duration-300 ease-in-out" href="">
        <svg class="rounded-full" width="118" height="113" viewBox="0 0 118 113" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 0V113H118V0H0ZM99.7979 25.004L85.9341 88.8642C85.6076 90.3719 83.7613 91.0552 82.4587 90.1487L63.5333 76.9907C62.3844 76.1918 60.8177 76.2343 59.7179 77.0931L49.2249 85.284C48.0073 86.2376 46.1722 85.7062 45.7059 84.2699L38.42 61.8311L19.5963 55.1035C17.6842 54.4176 17.6678 51.8325 19.5745 51.1291L96.8274 22.5898C98.4652 21.9833 100.155 23.3572 99.7979 25.004Z" fill="white"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M81.3206 36.5524L44.5321 58.2501C43.1221 59.0833 42.4584 60.714 42.9133 62.2406L46.8908 75.6245C47.1737 76.5727 48.6105 76.4759 48.7482 75.4961L49.7819 68.1566C49.9772 66.7748 50.6652 65.501 51.7327 64.55L82.0934 37.5239C82.6619 37.0198 81.9814 36.1637 81.3206 36.5524Z" fill="white"/>
        </svg>
      </a>
      <div class="px-20">
        <h2 class="mb-6 text-lg font-roboto text-gray-900 uppercase dark:text-white">Информация</h2>
        <ul class="text-gray-600 dark:text-gray-400 text-xl">
          <span>+7(800) 555 35 35</span><br>
          <span>Rcit@gmauil.com</span><br>
          <span>г.Якутск адрес:-------</span><br>
        </ul>
      </div>
    </div>
    <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
    <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2022 <a href="№" class="hover:underline">РЦИТ</a>. Все права защищены.
    </span>
</footer> 
  <div class="chatbot__btn">
    <div class="chatbot__tooltip d-none">Есть вопрос?</div>
  </div>

  <!-- FingerPrint JS -->
  <script src="/chatbot/fp2.js"></script>
  <!-- ChatBot JS -->
  <script src="/chatbot/chatbot.js"></script>

  <script>
    // конфигурация чат-бота
    const configChatbot = {};
    // CSS-селектор кнопки, посредством которой будем вызывать окно диалога с чат-ботом
    configChatbot.btn = '.chatbot__btn';
    // ключ для хранения отпечатка браузера
    configChatbot.key = 'fingerprint';
    // реплики чат-бота
    configChatbot.replicas = {
      bot: {
        0: { content: ['Привет!', 'Я Джаред - бот поддержки сайта <a href="http://trudinfo.h1n.ru" target="_blank">trudinfo.h1n.ru</a>'], human: [0, 1, 2] },
        1: { content: 'Я тоже рад, как мне к Вам обращаться?', human: [3] },
        2: { content: 'Как мне к Вам обращаться?', human: [3] },
        3: { content: '{{name}}, что Вас интересует?', human: [4, 5] },
        4: { content: '{{name}}, для этого перейдите на <a href=\"http://trudinfo.h1n.ru" target="_blank">эту страницу</a>. Она содержит подробную инструкцию по использованию этого чат-бота.', human: [6] },
        5: { content: "{{name}}, какой у Вас вопрос?", human: [7] },
        6: { content: '{{name}}, мы получили Ваш вопрос! Скажите, как с Вами удобнее будет связаться?', human: [8, 9] },
        7: { content: '{{name}}, укажите пожалуйста ваш телефон', human: [10] },
        8: { content: '{{name}}, укажите пожалуйста ваш Email ниже', human: [10] },
        9: { content: 'Готово! {{name}}, мы свяжемся с вами в ближайшее время по {{contact}}. Всего хорошего!', human: [6] },
      },
      human: {
        0: { content: 'Привет! Я рад с тобой познакомиться', bot: 1 },
        1: { content: 'Салют!', bot: 2 },
        2: { content: 'Привет, Джаред!', bot: 2 },
        3: { content: '', bot: 3, name: 'name' },
        4: { content: 'Меня интересует, как я могу устроится на работу ?', bot: 4 },
        5: { content: 'Хочу оставить резюме', bot: 5 },
        6: { content: 'В начало', bot: 3 },
        7: { content: '', bot: 6, name: '' },
        8: { content: 'по телефону', bot: 7 },
        9: { content: 'по email', bot: 8 },
        10: { content: '', bot: 9, name: 'contact' },
      }
    }
    // корневой элемент
    configChatbot.root = SimpleChatbot.createTemplate();
    // URL chatbot.php
    configChatbot.url = '/chatbot/chatbot.php';
    // создание SimpleChatbot
    let chatbot = new SimpleChatbot(configChatbot);
    // при клике по кнопке configChatbot.btn
    document.querySelector(configChatbot.btn).onclick = function (e) {
      this.classList.add('d-none');
      const $tooltip = this.querySelector('.chatbot__tooltip');
      if ($tooltip) {
        $tooltip.classList.add('d-none');
      }
      configChatbot.root.classList.toggle('chatbot_hidden');
      chatbot.init();
    };

    // добавление ключа для хранения отпечатка браузера в LocalStorage
    let fingerprint = localStorage.getItem(configChatbot.key);
    if (!fingerprint) {
      Fingerprint2.get(function (components) {
        fingerprint = Fingerprint2.x64hash128(components.map(function (pair) {
          return pair.value
        }).join(), 31)
        localStorage.setItem(configChatbot.key, fingerprint)
      });
    }

    // подсказка для кнопки
    const $btn = document.querySelector(configChatbot.btn);
    $btn.addEventListener('mouseover', function (e) {
      const $tooltip = $btn.querySelector('.chatbot__tooltip');
      if (!$tooltip.classList.contains('chatbot__tooltip_show')) {
        $tooltip.classList.remove('d-none');
        setTimeout(function () {
          $tooltip.classList.add('chatbot__tooltip_show');
        }, 0);
      }
    });
    $btn.addEventListener('mouseout', function (e) {
      const $tooltip = $btn.querySelector('.chatbot__tooltip');
      if ($tooltip.classList.contains('chatbot__tooltip_show')) {
        $tooltip.classList.remove('chatbot__tooltip_show');
        setTimeout(function () {
          $tooltip.classList.add('d-none');
        }, 200);
      }
    });

    setTimeout(function () {
      const tooltip = document.querySelector('.chatbot__tooltip');
      tooltip.classList.add('chatbot__tooltip_show');
      setTimeout(function () {
        tooltip.classList.remove('chatbot__tooltip_show');
      }, 10000)
    }, 10000);
  </script>
</body>
</html>
