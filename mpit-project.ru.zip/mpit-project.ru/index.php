<!DOCTYPE html>
<html lang="ru" class="bg-white">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Для доп функций tailwind -->
  <script src="https://unpkg.com/flowbite@1.4.4/dist/flowbite.js"></script>
  <!-- tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Слайдер + доп библиотека tailwind -->
  <link href="https://cdn.jsdelivr.net/npm/daisyui@2.14.3/dist/full.css" rel="stylesheet" type="text/css" />
  <!-- Чат бот -->
  <link href="chatbot/chatbot.css" rel="stylesheet" type="text/css" />
  <title>TrudInfo</title>
</head>
<body>
  <!-- Шапка -->
  <header class="container mx-auto px-2 bg-gray-200 z-100;" >
    <div class="flex items-center justify-between flex-wrap p-2">
      <!-- Логотип -->
      <a href="index.php" class="flex items-center flex-shrink-0 mr-14 hover:scale-110 transition delay-150 duration-300 ease-in-out" href="">
        <svg width="100" height="100" viewBox="0 0 673 649" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="326.5" cy="324.5" rx="326.5" ry="324.5" fill="#E32828"/>
        <path d="M500 189.413V554.413H177V113.413C194.771 113.413 211.091 113.413 226.5 113.413M500 189.413L422 113.413M500 189.413H422V113.413M422 113.413C344.092 113.413 294.055 113.413 226.5 113.413M226.5 113.413C226.5 49.412 324 56.4131 317 113.414L321 249.413C310 296.913 232.5 299.913 222.5 246.413V161.413C220 129.413 273.5 127.413 274.5 160.413L273.5 228.413" stroke="white" stroke-width="17" stroke-linejoin="round"/>
        <path d="M275.636 359V346.909H347.682V359H318.636V440H304.636V359H275.636ZM374.704 346.909V440H360.658V346.909H374.704Z" fill="white"/>
        <path d="M275.636 359H270.636V364H275.636V359ZM275.636 346.909V341.909H270.636V346.909H275.636ZM347.682 346.909H352.682V341.909H347.682V346.909ZM347.682 359V364H352.682V359H347.682ZM318.636 359V354H313.636V359H318.636ZM318.636 440V445H323.636V440H318.636ZM304.636 440H299.636V445H304.636V440ZM304.636 359H309.636V354H304.636V359ZM280.636 359V346.909H270.636V359H280.636ZM275.636 351.909H347.682V341.909H275.636V351.909ZM342.682 346.909V359H352.682V346.909H342.682ZM347.682 354H318.636V364H347.682V354ZM313.636 359V440H323.636V359H313.636ZM318.636 435H304.636V445H318.636V435ZM309.636 440V359H299.636V440H309.636ZM304.636 354H275.636V364H304.636V354ZM374.704 346.909H379.704V341.909H374.704V346.909ZM374.704 440V445H379.704V440H374.704ZM360.658 440H355.658V445H360.658V440ZM360.658 346.909V341.909H355.658V346.909H360.658ZM369.704 346.909V440H379.704V346.909H369.704ZM374.704 435H360.658V445H374.704V435ZM365.658 440V346.909H355.658V440H365.658ZM360.658 351.909H374.704V341.909H360.658V351.909Z" fill="white"/>
        </svg>
        <span class="text-5xl text-gray-600 font-bold tracking-tight">TrudInfo</span>
      </a>
      <div class="w-full block flex-grow lg:flex lg:items-center lg:w-auto mt-3">
        <div class="text-2xl lg:flex-grow">
          <!-- Навигация 1 -->
          <div class="group inline-block relative mx-4">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-1 px-10 rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out">
                <span class="mr-1">Услуги</span>
                <svg
                  class="fill-current h-4 w-4"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20">
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </button>
              <!-- Выпадающий список 1 -->
              <ul class="absolute hidden text-white pt-1 group-hover:block z-30">
                <li class="">
                  <a
                    class="rounded-t bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Поиск работы
                  </a>
                </li>
                <li class="">
                  <a
                    class="bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Новые вакансии
                  </a>
                </li>
                <li class="">
                  <a
                    class="rounded-b bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">О конкурсах
                  </a>
                </li>
              </ul>
            </div>
            <!-- Навигация 2 -->
             <div class="group inline-block relative mx-2">
              <a href="contests.php"
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-1 px-10  rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out ">
                <span>Конкурсы</span>
              </a>
            </div>
            <!-- Навигация 3 -->
             <div class="group inline-block relative mx-4">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-1 px-10  rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out">
                <span class="mr-1">Документация</span>
                <svg
                  class="fill-current h-4 w-4"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20">
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </button>
              <!-- Выпадающий список 3 -->
              <ul class="absolute hidden text-white pt-1 group-hover:block z-30">
                <li class="">
                  <a
                    class="rounded-t bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Заявления
                  </a>
                </li>
                <li class="">
                  <a
                    class="bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Извещения
                  </a>
                </li>
                <li class="">
                  <a
                    class="rounded-b bg-gray-600 hover:bg-red-600 py-2 px-10 block whitespace-no-wrap"
                    href="#">Сведения
                  </a>
                </li>
              </ul>
            </div>
            <!-- Навигация 4 -->
             <div class="group inline-block relative mx-4">
              <button
                class="bg-gray-600 text-white hover:bg-red-600 hover:scale-110 font-roboto py-1 px-10 rounded-full inline-flex items-center transition delay-150 duration-300 ease-in-out">
                <span class="mr-1">Акты</span>
              </button>  
            </div>
          </div>
        </div>
      </div>
  </header>
  <!-- Основа -->
  <main>
    <!-- Слайдер -->
    <div class="container mx-auto my-10 max-w-4xl">       
      <div id="default-carousel" class="relative" data-carousel="static">
          <div class="overflow-hidden relative h-56 rounded-lg xl:h-64 xl:h-90 xl:h-96">
               <!-- слайд 1 -->
              <div class="hidden duration-700 ease-in-out" data-carousel-item>
                  <img src="img/slide11.png" class="block absolute top-1/2 left-1/2 w-full -translate-x-1/2 -translate-y-1/2" alt="...">
              </div>
              <!-- слайд 2 -->
              <div class="hidden duration-700 ease-in-out" data-carousel-item>
                  <img src="img/slide2.png" class="block absolute top-1/2 left-1/2 w-full -translate-x-1/2 -translate-y-1/2" alt="...">
              </div>
              <!-- слайд 3 -->
              <div class="hidden duration-700 ease-in-out" data-carousel-item>
                  <img src="img/slide3.png" class="block absolute top-1/2 left-1/2 w-full -translate-x-1/2 -translate-y-1/2" alt="...">
              </div>
          </div>
          <!-- Слайдер пины -->
          <div class="flex absolute bottom-5 left-1/2 z-30 space-x-3 -translate-x-1/2">
              <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 1" data-carousel-slide-to="0"></button>
              <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 2" data-carousel-slide-to="1"></button>
              <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 3" data-carousel-slide-to="2"></button>
          </div>
          <!-- слайдер контроллеры -->
          <button type="button" class="flex absolute top-0 left-0 z-30 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none" data-carousel-prev>
              <span class="inline-flex justify-center items-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-white/30 dark:bg-gray-800/30 group-hover:bg-white/50 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                  <svg class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                  <span class="hidden">Пред</span>
              </span>
          </button>
          <button type="button" class="flex absolute top-0 right-0 z-30 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none" data-carousel-next>
              <span class="inline-flex justify-center items-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-white/30 dark:bg-gray-800/30 group-hover:bg-white/50 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                  <svg class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                  <span class="hidden">След</span>
              </span>
          </button>
      </div>
    </div>
    <!-- Инфа -->
    <div class="container mx-auto my-3 max-w-4xl">
      <div class="grid grid-cols-2 gap-0">
        <!-- Инф.работа -->
        <div class=" transition delay-150 duration-300 ease-in-out hover:scale-110 p-4 max-w-[95%] bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3">
          <div class="shrink-0">
            <img class="h-20 w-20" src="/img/search.svg" >
          </div>
          <div>
            <div class="text-xl font-medium text-white">Хочешь найти </div>
            <p class="text-xl font-medium text-white">работу ?</p>
            <div class="w-full block flex-grow lg:flex lg:items-center lg:w-auto mt-3">
              <button class="bg-gray-600 text-white transition delay-150 duration-300 ease-in-out hover:bg-red-600 hover:scale-110 font-roboto py-2 px-5 rounded-l-full inline-flex items-center">
                  <span class="">rabotavsem</span>
              </button>
              <button class="bg-gray-600 text-white transition delay-150 duration-300 ease-in-out hover:bg-red-600 hover:scale-110 font-roboto py-2 px-5 rounded-r-full inline-flex items-center">
                  <span class="">rabota.ykt</span>
              </button>
            </div>
          </div>
        </div>
        <!-- Таймер -->
        <div class=" transition delay-150 duration-300 ease-in-out hover:scale-110 p-4 max-w-[95%] bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3">
          <div class="shrink-0">
            <svg class="h-20 w-20" id="Слой_1" data-name="Слой 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120.97872 194.76596"><defs><style>.cls-1{fill:#fff;stroke-width:5px;}.cls-1,.cls-2{stroke:#222220;stroke-miterlimit:10;}.cls-2{fill:#222220;stroke-width:2px;}</style></defs><path class="cls-1" d="M26.74467,163.85106C24.33442,148.34912,33.18211,135.30972,36.10639,131c9.08829-13.394,21.3779-18.866,19.57446-27.234a10.51377,10.51377,0,0,0-2.89361-4.93617C43.76038,88.6704,33.27534,74.12551,30.20869,67.57133,23.99393,54.2888,28.27833,31.14676,44.78724,20.19149c13.05109-8.66065,30.94119-7.83811,43.57446,1.02127,1.63968,1.14987,13.15573,9.4885,15.48935,24,2.146,13.34489-4.814,24.2598-12.76593,36.766a106.232,106.232,0,0,1-13.617,17.19149,10.5018,10.5018,0,0,0-3.06385,6.12766c-.59811,6.623,7.2721,10.60049,14.63831,18.55319,2.05777,2.2216,13.19241,14.24275,14.8085,30.29788.35117,3.48867,1.53589,15.2583-5.95743,25.3617-8.37158,11.28761-21.98285,12.95614-28.766,13.78723-6.06613.74324-14.934,1.82973-24.17022-3.06383C29.88471,182.24823,26.96357,165.25894,26.74467,163.85106Z" transform="translate(-5.51064 -6.08511)"/><path class="cls-2" d="M22.08512,18.31915A1.77451,1.77451,0,0,1,20.617,20.234c.85065,10.38017,1.364,21.60536,1.34042,33.57447-.02789,14.14336-.80151,27.2741-2,39.234a4.05786,4.05786,0,0,1,1.78727,2.97871A4.09959,4.09959,0,0,1,20.25532,99.383a5.81318,5.81318,0,0,1,1.40426,4.383,5.61392,5.61392,0,0,1-1.48938,3.14893,4.10214,4.10214,0,0,1,1.31915,4.766,3.94871,3.94871,0,0,1-2.46807,2q1.17009,14.79623,1.78723,30.6383c.55682,14.79578.648,28.98587.383,42.51064a2.08038,2.08038,0,0,1,1.48935.383,1.82162,1.82162,0,0,1,.68085,1.53191c-.19489.78939-2.57526,1.33937-11.617.51065a1.62007,1.62007,0,0,1-.25535-2.04256,1.58692,1.58692,0,0,1,1.53193-.63831,357.47435,357.47435,0,0,1-.89362-42.25531c.41577-10.92714,1.308-21.16711,2.48935-30.6383a4.07326,4.07326,0,0,1-2.36169-2.234,4.13206,4.13206,0,0,1,1.27661-4.53192,5.51871,5.51871,0,0,1-1.48938-3.44681,5.59369,5.59369,0,0,1,1.48938-4.02127A4.59243,4.59243,0,0,1,12.25532,95.617,4.366,4.366,0,0,1,13.82978,93c-.962-12.1723-1.53784-25.29409-1.51062-39.25532.02295-11.76274.47162-22.913,1.21277-33.383a1.78913,1.78913,0,0,1-1.21277-.57447A1.68658,1.68658,0,0,1,12,18.383C12.24,17.64047,14.36994,17.21574,22.08512,18.31915Z" transform="translate(-5.51064 -6.08511)"/><path class="cls-2" d="M119.87235,18.57446a1.77449,1.77449,0,0,1-1.46811,1.9149c.85065,10.38017,1.364,21.60536,1.34043,33.57447-.0279,14.14336-.80152,27.27411-2,39.23405a4.05787,4.05787,0,0,1,1.78726,2.97872,4.09958,4.09958,0,0,1-1.48938,3.36171,5.8131,5.8131,0,0,1,1.40426,4.383,5.61384,5.61384,0,0,1-1.48938,3.14892,4.10214,4.10214,0,0,1,1.31916,4.766,3.94866,3.94866,0,0,1-2.46808,2q1.17009,14.79622,1.78723,30.63831c.55682,14.79578.648,28.98587.383,42.51063a2.08048,2.08048,0,0,1,1.48935.383A1.82158,1.82158,0,0,1,121.14893,189c-.19488.7894-2.57525,1.33936-11.617.51065a1.62008,1.62008,0,0,1-.25534-2.04257,1.58693,1.58693,0,0,1,1.53192-.63831,357.474,357.474,0,0,1-.89362-42.25529c.41577-10.92714,1.308-21.16711,2.48935-30.63831a4.07322,4.07322,0,0,1-2.36169-2.234,4.13206,4.13206,0,0,1,1.27661-4.53192,5.51881,5.51881,0,0,1-1.48938-3.4468,5.5937,5.5937,0,0,1,1.48938-4.02128,4.59244,4.59244,0,0,1-1.27661-3.82978,4.366,4.366,0,0,1,1.57446-2.617C110.655,81.083,110.07917,67.96123,110.10639,54c.02295-11.76274.47162-22.913,1.21277-33.383a1.78913,1.78913,0,0,1-1.21277-.57447,1.68662,1.68662,0,0,1-.31915-1.40425C110.0272,17.89578,112.15717,17.47106,119.87235,18.57446Z" transform="translate(-5.51064 -6.08511)"/><rect class="cls-2" x="2.85106" y="4.06383" width="115.40426" height="8.17021" rx="4.0851"/><rect class="cls-2" x="1.51064" y="1" width="118.46809" height="8.17021" rx="4.0851"/><rect class="cls-2" x="2.34043" y="182.53191" width="115.40426" height="8.17021" rx="4.0851"/><rect class="cls-2" x="1" y="185.59574" width="118.46809" height="8.17021" rx="4.0851"/><path class="cls-2" d="M35.95746,167.90052c-.6853-1.91693-2.11173-5.907-.25534-9.76271a12.02642,12.02642,0,0,1,4.766-4.79862c4.05136-2.66419,5.73276-1.61576,12-4.21947,4.30038-1.78658,6.45056-2.67987,8.51065-4.88135,2.03717-2.177,2.82382-4.34431,4.42554-4.30222,1.36514.03589,2.12368,1.64521,3.14892,2.97845,2.18924,2.847,4.66114,3.22124,12.42554,6.03965,8.45605,3.06947,12.71124,4.64614,14.04254,6.70152,2.67514,4.13016.87955,9.53178.17023,11.6656-3.09284,9.304-12.0976,13.662-14.29788,14.7268-12.71271,6.15241-27.50739,2.7804-36.34043-3.55759C42.50742,177.02267,38.04132,173.72965,35.95746,167.90052Z" transform="translate(-5.51064 -6.08511)"/><path class="cls-2" d="M35.44681,62.06383a64.19407,64.19407,0,0,0,28.766,6.6383,64.24455,64.24455,0,0,0,29.95746-7.65957,73.07961,73.07961,0,0,1-13.617,22.8085A79.40852,79.40852,0,0,0,68.12766,100.3617c-1.419,2.581-2.42509,4.79823-3.06383,6.29788a55.63075,55.63075,0,0,0-2.72341-6.12766c-4.36709-8.41786-9.67028-13.33026-12.42553-16.17022A73.19446,73.19446,0,0,1,35.44681,62.06383Z" transform="translate(-5.51064 -6.08511)"/></svg>
          </div>
          <div>
            <div class="text-xl font-medium text-white">До конкурса осталось:</div>
              <div id="timer" class="text-2xl text-white font-bold"></div>
              <!-- Таймер скрипт -->
              <script type="text/javascript">
                function updateTimer() {
                  future = Date.parse("May 4, 2022 18:00:00");
                 now = new Date();
                 diff = future - now;

                 days = Math.floor(diff / (1000 * 60 * 60 * 24));
                 hours = Math.floor(diff / (1000 * 60 * 60));
                 mins = Math.floor(diff / (1000 * 60));
                 secs = Math.floor(diff / 1000);

                 d = days;
                 h = hours - days * 24;
                 m = mins - hours * 60;
                 s = secs - mins * 60;

                 document.getElementById("timer")
                  .innerHTML =
                  d + 'д' +
                  h + 'ч' +
                  m + 'м' +
                  s + 'с';
                }
                setInterval('updateTimer()', 1000);
              </script>
            <div class="w-full block flex-grow lg:flex lg:items-center lg:w-auto mt-3">
            </div>
          </div>
        </div>
      </div>
    </div>
      <!-- Информационная навигация -->
    <div class="container mx-auto my-10 max-w-6xl">
        <div class="grid grid-cols-3 gap-2">
          <a href="#" class="p-4 max-w-max bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3" data-modal-toggle="defaultModal">
              <div>
                <span class="text-3xl font-bold text-white">ПЕРВЫЕ ШАГИ В КАРЬЕРЕ</span>
                <img class="hover:scale-110 transition delay-650" src="img/inf-nav-1.svg">
              </div>
              <div>
                  <span class="text-xl font-medium text-white">Найдите чем хотите заняться и начните повышать свои навыки в этой облости </span>
              </div>
          </a>
          <a href="#" class="p-4 max-w-max bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3" data-modal-toggle="defaultModal">
            <div>
              <div class="">
                <span class=" w-100 text-2xl font-bold text-white">ПОВЫСИТЬ КВАЛИФИКАЦИЮ</span>
              </div>
              <div >
                <span class="text-xl font-medium text-white">Улушите свои знания и релизуйте их на практике в своих проектах</span>
              </div>
            </div>
            <div class="mt-20">
              <img class="hover:scale-110 transition delay-650 xl:h-64" src="img/inf-nav-2.svg">
            </div>
          </a>
          <a href="#" class="p-4 max-w-max bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3" data-modal-toggle="defaultModal">
            <div>
              <div class="">
                <span class=" w-100 text-2xl font-bold text-white">КАРЬЕРНОЕ КОНСУЛЬТИРОВАНИЕ</span>
              </div>
              <div >
                <span class="text-xl font-medium text-white">Новый сервис в службе занятости</span>
              </div>
            </div>
            <div class="mt-20">
              <img class="hover:scale-110 transition delay-650 xl:h-64" src="img/inf-nav-3.svg">
            </div>
          </a>
          <a href="#" class="p-4 max-w-max bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3" data-modal-toggle="defaultModal">
            <div>
              <div class="">
                <span class=" w-100 text-2xl font-bold text-white">РАБОТА В КОЛЛИКТИВЕ</span>
              </div>
              <div >
                <span class="text-lg font-medium text-white">Всегда найдётся совместная работа в коллективе.</span>
              </div>
            </div>
            <div class="mt-20">
              <img class="hover:scale-110 transition delay-650 lg:h-64" src="img/inf-nav-4.svg">
            </div>
          </a>
          <a href="#" class="p-4 max-w-max bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3" data-modal-toggle="defaultModal">
            <div>
              <div class="">
                <span class=" w-100 text-2xl font-bold text-white">ОТКРЫТЬ СОБСТВЕННОЕ ДЕЛО</span>
              </div>
              <div >
                <span class="text-xl font-medium text-white"></span>
              </div>
            </div>
            <div class="mt-20">
              <img class="hover:scale-110 transition delay-650 lg:h-64" src="img/inf-nav-5.svg">
            </div>
          </a>
          <a href="#" class="p-4 max-w-max bg-red-400 rounded-xl hover:bg-gray-400 shadow-lg flex items-center space-x-3" data-modal-toggle="defaultModal">
              <div>
                <span class="text-2xl font-bold text-white">ИНТЕРЕСНЫЕ ПРОЕКТЫ</span>
                <div>
                  <span class="text-xl font-medium text-white">Много интерсных задач которые требуют правильного подхода</span>
              </div>
                <img class="hover:scale-110 transition delay-650" src="img/inf-nav-6.svg">
              </div>
          </a>
        </div>
    </div>
    <div id="defaultModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 w-full md:inset-0 h-modal md:h-full">
    <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
        <!-- Модульное окно -->
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <!-- Модульное окно-->
            <div class="flex justify-between items-start p-4 rounded-t border-b dark:border-gray-600">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                    Ошибка
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-toggle="defaultModal">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>  
                </button>
            </div>
            <!-- Modal body -->
            <div class="p-6 space-y-6">
                <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                    Здравствуйте, мы сожелеем такой страницы пока не существует. 
                </p>
                <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                    Дождитсь разработчика пока он не обновит сайт и страницы станут доступными.
                </p>
            </div>
            <!-- Modal footer -->
            <div class="flex items-center p-6 space-x-2 rounded-b border-t border-gray-200 dark:border-gray-600">
                <button data-modal-toggle="defaultModal" type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Хорошо</button>
                <button data-modal-toggle="defaultModal" type="button" class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">Закрыть</button>
            </div>
        </div>
    </div>
</div>
  </main>
  <!-- Подвал -->
  <footer class="p-4 bg-white shadow md:px-6 md:py-8 dark:bg-gray-800">
    <div class="sm:flex sm:items-center sm:justify-between">
        <a class="flex items-center flex-shrink-0 mr-14 hover:scale-110 transition delay-150 duration-300 ease-in-out" href="">
        <svg width="92" height="136" viewBox="0 0 92 136" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M89 35.4492V133H3V15.1373C7.73147 15.1373 12.0769 15.1373 16.1796 15.1373M89 35.4492L68.2322 15.1373M89 35.4492H68.2322V15.1373M68.2322 15.1373C47.4889 15.1373 34.1663 15.1373 16.1796 15.1373M16.1796 15.1373C16.1796 -1.96788 42.1393 -0.0967461 40.2755 15.1375L41.3406 51.4849C38.4118 64.1799 17.7771 64.9816 15.1146 50.6831V27.9658C14.4489 19.4134 28.6935 18.8789 28.9598 27.6985L28.6935 45.8724" stroke="white" stroke-width="5" stroke-linejoin="round"/>
          <path d="M26.7173 83.3203V79.6364H48.6687V83.3203H39.8189V108H35.5533V83.3203H26.7173ZM56.9019 79.6364V108H52.6224V79.6364H56.9019Z" fill="white"/>
          <path d="M26.7173 83.3203H25.7173V84.3203H26.7173V83.3203ZM26.7173 79.6364V78.6364H25.7173V79.6364H26.7173ZM48.6687 79.6364H49.6687V78.6364H48.6687V79.6364ZM48.6687 83.3203V84.3203H49.6687V83.3203H48.6687ZM39.8189 83.3203V82.3203H38.8189V83.3203H39.8189ZM39.8189 108V109H40.8189V108H39.8189ZM35.5533 108H34.5533V109H35.5533V108ZM35.5533 83.3203H36.5533V82.3203H35.5533V83.3203ZM27.7173 83.3203V79.6364H25.7173V83.3203H27.7173ZM26.7173 80.6364H48.6687V78.6364H26.7173V80.6364ZM47.6687 79.6364V83.3203H49.6687V79.6364H47.6687ZM48.6687 82.3203H39.8189V84.3203H48.6687V82.3203ZM38.8189 83.3203V108H40.8189V83.3203H38.8189ZM39.8189 107H35.5533V109H39.8189V107ZM36.5533 108V83.3203H34.5533V108H36.5533ZM35.5533 82.3203H26.7173V84.3203H35.5533V82.3203ZM56.9019 79.6364H57.9019V78.6364H56.9019V79.6364ZM56.9019 108V109H57.9019V108H56.9019ZM52.6224 108H51.6224V109H52.6224V108ZM52.6224 79.6364V78.6364H51.6224V79.6364H52.6224ZM55.9019 79.6364V108H57.9019V79.6364H55.9019ZM56.9019 107H52.6224V109H56.9019V107ZM53.6224 108V79.6364H51.6224V108H53.6224ZM52.6224 80.6364H56.9019V78.6364H52.6224V80.6364Z" fill="white"/>
          </svg>
        <span class="text-5xl text-white font-roboto tracking-tight">TrudInfo</span>
      </a>
      <a class="flex items-center flex-shrink-0 mr-14 hover:scale-110 transition delay-150 duration-300 ease-in-out" href="">
        <svg class="rounded-full" width="118" height="113" viewBox="0 0 118 113" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 0V113H118V0H0ZM99.7979 25.004L85.9341 88.8642C85.6076 90.3719 83.7613 91.0552 82.4587 90.1487L63.5333 76.9907C62.3844 76.1918 60.8177 76.2343 59.7179 77.0931L49.2249 85.284C48.0073 86.2376 46.1722 85.7062 45.7059 84.2699L38.42 61.8311L19.5963 55.1035C17.6842 54.4176 17.6678 51.8325 19.5745 51.1291L96.8274 22.5898C98.4652 21.9833 100.155 23.3572 99.7979 25.004Z" fill="white"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M81.3206 36.5524L44.5321 58.2501C43.1221 59.0833 42.4584 60.714 42.9133 62.2406L46.8908 75.6245C47.1737 76.5727 48.6105 76.4759 48.7482 75.4961L49.7819 68.1566C49.9772 66.7748 50.6652 65.501 51.7327 64.55L82.0934 37.5239C82.6619 37.0198 81.9814 36.1637 81.3206 36.5524Z" fill="white"/>
        </svg>
      </a>
      <div class="px-20">
        <h2 class="mb-6 text-lg font-roboto text-gray-900 uppercase dark:text-white">Информация</h2>
        <ul class="text-gray-600 dark:text-gray-400 text-xl">
          <span>+7(800) 555 35 35</span><br>
          <span>Rcit@gmail.com</span><br>
          <span>г.Якутск адрес:-------</span><br>
        </ul>
      </div>
    </div>
    <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
    <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2022 <a href="№" class="hover:underline">РЦИТ</a>. Все права защищены.
    </span>
</footer> 
<div class="chatbot__btn">
    <div class="chatbot__tooltip d-none">Есть вопрос?</div>
  </div>

  <!-- FingerPrint JS -->
  <script src="/chatbot/fp2.js"></script>
  <!-- ChatBot JS -->
  <script src="/chatbot/chatbot.js"></script>

  <script>
    // конфигурация чат-бота
    const configChatbot = {};
    // CSS-селектор кнопки, посредством которой будем вызывать окно диалога с чат-ботом
    configChatbot.btn = '.chatbot__btn';
    // ключ для хранения отпечатка браузера
    configChatbot.key = 'fingerprint';
    // реплики чат-бота
    configChatbot.replicas = {
      bot: {
        0: { content: ['Привет!', 'Я Джаред - бот поддержки сайта <a href=\"http://trudinfo.h1n.ru"\ target="_blank">trudinfo.h1n.ru</a>'], human: [0, 1, 2] },
        1: { content: 'Я тоже рад, как мне к Вам обращаться?', human: [3] },
        2: { content: 'Как мне к Вам обращаться?', human: [3] },
        3: { content: '{{name}}, что Вас интересует?', human: [4, 5] },
        4: { content: '{{name}}, для этого перейдите на <a href=\"http://trudinfo.h1n.ru"\ target="_blank">эту страницу</a>. Она содержит подробную инструкцию по использованию этого чат-бота.', human: [6] },
        5: { content: "{{name}}, какой у Вас вопрос?", human: [7] },
        6: { content: '{{name}}, мы получили Ваш вопрос! Скажите, как с Вами удобнее будет связаться?', human: [8, 9] },
        7: { content: '{{name}}, укажите пожалуйста ваш телефон', human: [10] },
        8: { content: '{{name}}, укажите пожалуйста ваш Email ниже', human: [10] },
        9: { content: 'Готово! {{name}}, мы свяжемся с вами в ближайшее время по {{contact}}. Всего хорошего!', human: [6] },
      },
      human: {
        0: { content: 'Привет! Я рад с тобой познакомиться', bot: 1 },
        1: { content: 'Салют!', bot: 2 },
        2: { content: 'Привет, Джаред!', bot: 2 },
        3: { content: '', bot: 3, name: 'name' },
        4: { content: 'Меня интересует, как я могу устроится на работу ?', bot: 4 },
        5: { content: 'Хочу оставить резюме', bot: 5 },
        6: { content: 'В начало', bot: 3 },
        7: { content: '', bot: 6, name: '' },
        8: { content: 'по телефону', bot: 7 },
        9: { content: 'по email', bot: 8 },
        10: { content: '', bot: 9, name: 'contact' },
      }
    }
    // корневой элемент
    configChatbot.root = SimpleChatbot.createTemplate();
    // URL chatbot.php
    configChatbot.url = '/chatbot/chatbot.php';
    // создание SimpleChatbot
    let chatbot = new SimpleChatbot(configChatbot);
    // при клике по кнопке configChatbot.btn
    document.querySelector(configChatbot.btn).onclick = function (e) {
      this.classList.add('d-none');
      const $tooltip = this.querySelector('.chatbot__tooltip');
      if ($tooltip) {
        $tooltip.classList.add('d-none');
      }
      configChatbot.root.classList.toggle('chatbot_hidden');
      chatbot.init();
    };

    // добавление ключа для хранения отпечатка браузера в LocalStorage
    let fingerprint = localStorage.getItem(configChatbot.key);
    if (!fingerprint) {
      Fingerprint2.get(function (components) {
        fingerprint = Fingerprint2.x64hash128(components.map(function (pair) {
          return pair.value
        }).join(), 31)
        localStorage.setItem(configChatbot.key, fingerprint)
      });
    }

    // подсказка для кнопки
    const $btn = document.querySelector(configChatbot.btn);
    $btn.addEventListener('mouseover', function (e) {
      const $tooltip = $btn.querySelector('.chatbot__tooltip');
      if (!$tooltip.classList.contains('chatbot__tooltip_show')) {
        $tooltip.classList.remove('d-none');
        setTimeout(function () {
          $tooltip.classList.add('chatbot__tooltip_show');
        }, 0);
      }
    });
    $btn.addEventListener('mouseout', function (e) {
      const $tooltip = $btn.querySelector('.chatbot__tooltip');
      if ($tooltip.classList.contains('chatbot__tooltip_show')) {
        $tooltip.classList.remove('chatbot__tooltip_show');
        setTimeout(function () {
          $tooltip.classList.add('d-none');
        }, 200);
      }
    });

    setTimeout(function () {
      const tooltip = document.querySelector('.chatbot__tooltip');
      tooltip.classList.add('chatbot__tooltip_show');
      setTimeout(function () {
        tooltip.classList.remove('chatbot__tooltip_show');
      }, 10000)
    }, 10000);
  </script>
</body>
</html>
